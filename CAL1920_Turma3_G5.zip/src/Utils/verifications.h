#ifndef EXPLOREIT_VERIFICATIONS_H
#define EXPLOREIT_VERIFICATIONS_H

#include <iostream>
#include "utils.h"

using namespace std;

void verifyAllLetters(string &aux);

void verifyMenuOptions(int &option, int omin, int nmax);


#endif //EXPLOREIT_VERIFICATIONS_H
