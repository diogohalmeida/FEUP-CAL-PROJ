Dependências:
- GraphViewer (./lib/)
- Maps (./resources/)

Instruções de Compilação:
A pasta do projeto corresponde a um projeto CLion realizado em Windows. 
Para o compilar e executar basta abri-la como um projeto CLion, dar reload no CMakeLists.txt e de seguida clicar "Run".